package com.example.byrdyshevka;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;

/**
 * Мод "Село Бырдыщевка".
 * Команда /byrdyshevka строит село вокруг игрока:
 * дорога, большие деревянные дома, пруд, табличка при въезде,
 * бырдыщи (живут в домах и ходят купаться) и баба Клава со скримером.
 */
public class Byrdyshevka implements ModInitializer {

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(CommandManager.literal("byrdyshevka")
                        .requires(src -> src.hasPermissionLevel(2) || src.getServer().isSingleplayer())
                        .executes(ctx -> {
                            ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                            ServerWorld world = player.getServerWorld();
                            VillageBuilder.build(world, player.getBlockPos().down());
                            ctx.getSource().sendFeedback(
                                    () -> Text.literal("Село Бырдыщевка построено! Осторожно, баба Клава рядом."),
                                    true);
                            return 1;
                        })));

        // Жизнь села: бырдыщи ходят купаться, баба Клава гоняет игроков
        ServerTickEvents.END_WORLD_TICK.register(VillageLife::tick);
    }
}

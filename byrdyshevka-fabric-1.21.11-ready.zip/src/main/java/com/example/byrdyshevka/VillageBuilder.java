package com.example.byrdyshevka;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.SignBlockEntity;
import net.minecraft.block.entity.SignText;
import net.minecraft.block.enums.BedPart;
import net.minecraft.block.enums.DoubleBlockHalf;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.VindicatorEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.util.DyeColor;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.util.Random;

/**
 * Строит село. Центр села = позиция игрока, вход (табличка) с южной стороны (+Z).
 * Занимает примерно 51 x 55 блоков. Встань на ровной суше!
 */
public final class VillageBuilder {

    private record Style(Block planks, Block log, Block stairs, Block floor, Block door) {}

    private static final String[] NAMES = {
            "Бырдыщ", "Бырдыщка", "Бырдыщок", "Дядя Бырдыщ", "Бырдыщ Петрович", "Бырдыщиха"
    };

    private VillageBuilder() {}

    public static void build(ServerWorld w, BlockPos ground) {
        final int ox = ground.getX();
        final int gy = ground.getY();
        final int oz = ground.getZ();
        Random rnd = new Random();

        BlockState air = Blocks.AIR.getDefaultState();
        BlockState dirt = Blocks.DIRT.getDefaultState();
        BlockState grass = Blocks.GRASS_BLOCK.getDefaultState();
        BlockState path = Blocks.DIRT_PATH.getDefaultState();

        // ---------- 1. Выравниваем площадку ----------
        for (int x = ox - 25; x <= ox + 25; x++) {
            for (int z = oz - 27; z <= oz + 27; z++) {
                for (int y = gy - 8; y < gy; y++) {
                    BlockState s = w.getBlockState(new BlockPos(x, y, z));
                    if (s.isAir() || !s.getFluidState().isEmpty() || s.isReplaceable()) {
                        set(w, x, y, z, dirt);
                    }
                }
                set(w, x, gy, z, grass);
                for (int y = gy + 1; y <= gy + 16; y++) {
                    set(w, x, y, z, air);
                }
            }
        }

        // ---------- 2. Большой пруд ----------
        final int pcx = ox - 13, pcz = oz - 4, rx = 9, rz = 8;
        final int pierMin = pcx + rx - 7, pierMax = pcx + rx + 1;
        BlockState water = Blocks.WATER.getDefaultState();
        BlockState sand = Blocks.SAND.getDefaultState();
        for (int x = pcx - rx - 3; x <= pcx + rx + 3; x++) {
            for (int z = pcz - rz - 3; z <= pcz + rz + 3; z++) {
                double dx = (x - pcx) / (double) rx;
                double dz = (z - pcz) / (double) rz;
                double d = dx * dx + dz * dz;
                if (d <= 1.0) {
                    set(w, x, gy, z, water);
                    set(w, x, gy - 1, z, water);
                    set(w, x, gy - 2, z, water);
                    set(w, x, gy - 3, z, sand);
                    boolean onPier = z >= pcz && z <= pcz + 1 && x >= pierMin;
                    if (d <= 0.8 && !onPier && rnd.nextInt(8) == 0) {
                        set(w, x, gy + 1, z, Blocks.LILY_PAD.getDefaultState());
                    }
                } else if (d <= 1.35) {
                    set(w, x, gy, z, sand);
                }
            }
        }
        // Мостки в пруд
        for (int x = pierMin; x <= pierMax; x++) {
            for (int z = pcz; z <= pcz + 1; z++) {
                set(w, x, gy, z, Blocks.OAK_PLANKS.getDefaultState());
            }
        }
        for (int z = pcz; z <= pcz + 1; z++) {
            set(w, pierMin, gy + 1, z, Blocks.OAK_FENCE.getDefaultState());
            set(w, pierMin, gy + 2, z, Blocks.LANTERN.getDefaultState());
        }

        // ---------- 3. Дорога ----------
        for (int z = oz - 27; z <= oz + 27; z++) {
            for (int x = ox - 1; x <= ox + 1; x++) {
                set(w, x, gy, z, path);
            }
        }

        // ---------- 4. Дома ----------
        Style normal = new Style(Blocks.OAK_PLANKS, Blocks.OAK_LOG, Blocks.SPRUCE_STAIRS,
                Blocks.SPRUCE_PLANKS, Blocks.OAK_DOOR);
        Style klavaStyle = new Style(Blocks.SPRUCE_PLANKS, Blocks.DARK_OAK_LOG, Blocks.DARK_OAK_STAIRS,
                Blocks.DARK_OAK_PLANKS, Blocks.SPRUCE_DOOR);

        final int eastX = ox + 4;   // восточные дома, дверь смотрит на запад (на дорогу)
        final int westX = ox - 9;   // западные дома, дверь смотрит на восток (на дорогу)

        int klavaHz = oz - 20;
        house(w, eastX, gy, klavaHz, true, klavaStyle);
        house(w, eastX, gy, oz - 9, true, normal);
        house(w, eastX, gy, oz + 2, true, normal);
        house(w, westX, gy, oz + 8, false, normal);
        house(w, westX, gy, oz - 23, false, normal);

        // Тропинки от дороги к дверям
        for (int hz : new int[]{klavaHz, oz - 9, oz + 2}) {
            for (int x = ox + 2; x <= ox + 3; x++) {
                set(w, x, gy, hz + 4, path);
            }
        }
        for (int hz : new int[]{oz + 8, oz - 23}) {
            set(w, ox - 2, gy, hz + 4, path);
        }

        // Огород и табличка у бабы Клавы
        BlockState pumpkin = Blocks.PUMPKIN.getDefaultState();
        set(w, eastX - 2, gy + 1, klavaHz + 1, pumpkin);
        set(w, eastX - 2, gy + 1, klavaHz + 2, pumpkin);
        set(w, eastX - 2, gy + 1, klavaHz + 7, Blocks.CARVED_PUMPKIN.getDefaultState()
                .with(Properties.HORIZONTAL_FACING, Direction.WEST));
        sign(w, eastX - 1, gy + 3, klavaHz + 4, Direction.WEST, DyeColor.RED, false,
                "ОСТОРОЖНО!", "ЗЛАЯ СОСЕДКА", "БАБА КЛАВА", "(не стучать)");

        // ---------- 5. Въезд в село с табличкой ----------
        int sz = oz + 22;
        BlockState logY = Blocks.OAK_LOG.getDefaultState();
        BlockState planks = Blocks.OAK_PLANKS.getDefaultState();
        for (int y = 1; y <= 4; y++) {
            set(w, ox + 3, gy + y, sz, logY);
            set(w, ox + 7, gy + y, sz, logY);
        }
        for (int x = ox + 4; x <= ox + 6; x++) {
            set(w, x, gy + 3, sz, planks);
            set(w, x, gy + 4, sz, planks);
        }
        for (int x = ox + 3; x <= ox + 7; x++) {
            set(w, x, gy + 5, sz, Blocks.SPRUCE_SLAB.getDefaultState());
        }
        sign(w, ox + 4, gy + 3, sz + 1, Direction.SOUTH, DyeColor.ORANGE, true,
                "Добро", "пожаловать", "в село", "");
        sign(w, ox + 5, gy + 3, sz + 1, Direction.SOUTH, DyeColor.RED, true,
                "~ СЕЛО ~", "БЫРДЫЩЕВКА", "", "");
        sign(w, ox + 6, gy + 3, sz + 1, Direction.SOUTH, DyeColor.ORANGE, true,
                "Пруд: есть", "Бырдыщи: есть", "Баба Клава:", "ЕСТЬ!!!");
        sign(w, ox + 5, gy + 3, sz - 1, Direction.NORTH, DyeColor.ORANGE, true,
                "Приходите", "ещё!", "", "");

        // ---------- 6. Фонари вдоль дороги ----------
        for (int dz : new int[]{-24, -12, 0, 12, 24}) {
            lamp(w, ox + 2, gy, oz + dz);
        }
        for (int dz : new int[]{-10, 0, 20}) {
            lamp(w, ox - 2, gy, oz + dz);
        }

        // ---------- 7. Жители ----------
        // {x дома, z дома, 1 = дверь на западной стене}
        int[][] homes = {
                {eastX, oz - 9, 1},
                {eastX, oz + 2, 1},
                {westX, oz + 8, 0},
                {westX, oz - 23, 0}
        };
        for (int[] h : homes) {
            boolean low = h[2] == 1;
            double inX = low ? h[0] + 1.5 : h[0] + 5.5;
            double outX = low ? h[0] - 0.5 : h[0] + 7.5;
            double doorZ = h[1] + 4.5;
            double roadX = ox + 0.5;
            double[] homeZs = {h[1] + 2.5, h[1] + 5.5};
            for (double homeZ : homeZs) {
                double homeX = h[0] + 3.5;
                VillagerEntity v = new VillagerEntity(EntityType.VILLAGER, w);
                v.refreshPositionAndAngles(homeX, gy + 1.0, homeZ, rnd.nextInt(360), 0f);
                v.setCustomName(Text.literal(NAMES[rnd.nextInt(NAMES.length)]));
                v.setCustomNameVisible(true);
                v.setAiDisabled(true);
                v.setNoGravity(true);
                v.setInvulnerable(true);
                v.setPersistent();
                v.addCommandTag(VillageLife.makeTag(homeX, homeZ, inX, outX, doorZ, roadX,
                        gy, pcx, pcz, rx, rz));
                w.spawnEntity(v);
            }
        }

        // Баба Клава стоит у своей калитки
        VindicatorEntity k = new VindicatorEntity(EntityType.VINDICATOR, w);
        k.refreshPositionAndAngles(eastX - 1.5, gy + 1.0, klavaHz + 4.5, 90f, 0f);
        k.setCustomName(Text.literal("Баба Клава").formatted(Formatting.RED, Formatting.BOLD));
        k.setCustomNameVisible(true);
        k.setPersistent();
        k.getAttributeInstance(EntityAttributes.MAX_HEALTH).setBaseValue(60.0);
        k.getAttributeInstance(EntityAttributes.ATTACK_DAMAGE).setBaseValue(8.0);
        k.getAttributeInstance(EntityAttributes.MOVEMENT_SPEED).setBaseValue(0.38);
        k.setHealth(60.0f);
        ItemStack rollingPin = new ItemStack(Items.STICK);
        rollingPin.set(DataComponentTypes.CUSTOM_NAME, Text.literal("Скалка бабы Клавы"));
        k.equipStack(EquipmentSlot.MAINHAND, rollingPin);
        k.addCommandTag("klava");
        w.spawnEntity(k);
    }

    // ------------------------------------------------------------------
    // Дом: 7 x 9 блоков, стены высотой 4, двускатная крыша
    // ------------------------------------------------------------------
    private static void house(ServerWorld w, int hx, int gy, int hz, boolean low, Style st) {
        BlockState planks = st.planks().getDefaultState();
        BlockState log = st.log().getDefaultState();
        BlockState floor = st.floor().getDefaultState();
        BlockState glass = Blocks.GLASS.getDefaultState();

        // Пол, стены, потолок
        for (int lx = 0; lx <= 6; lx++) {
            for (int lz = 0; lz <= 8; lz++) {
                int x = hx + lx, z = hz + lz;
                set(w, x, gy, z, floor);
                boolean ex = lx == 0 || lx == 6;
                boolean ez = lz == 0 || lz == 8;
                if (ex || ez) {
                    BlockState wall = (ex && ez) ? log : planks;
                    for (int y = 1; y <= 4; y++) {
                        set(w, x, gy + y, z, wall);
                    }
                }
                set(w, x, gy + 5, z, planks);
            }
        }

        // Крыша
        BlockState stairsE = st.stairs().getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.EAST);
        BlockState stairsW = st.stairs().getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.WEST);
        for (int lz = -1; lz <= 9; lz++) {
            for (int k = 0; k <= 3; k++) {
                set(w, hx - 1 + k, gy + 5 + k, hz + lz, stairsE);
                set(w, hx + 7 - k, gy + 5 + k, hz + lz, stairsW);
            }
            set(w, hx + 3, gy + 8, hz + lz, floor);
        }
        // Треугольные фронтоны
        for (int lz : new int[]{0, 8}) {
            for (int lx = 1; lx <= 5; lx++) {
                set(w, hx + lx, gy + 6, hz + lz, planks);
            }
            for (int lx = 2; lx <= 4; lx++) {
                set(w, hx + lx, gy + 7, hz + lz, planks);
            }
        }

        // Дверь (открыта, чтобы бырдыщи проходили)
        int dlx = low ? 0 : 6;
        Direction out = low ? Direction.WEST : Direction.EAST;
        BlockState door = st.door().getDefaultState()
                .with(Properties.HORIZONTAL_FACING, out)
                .with(Properties.OPEN, true);
        set(w, hx + dlx, gy + 1, hz + 4, door.with(Properties.DOUBLE_BLOCK_HALF, DoubleBlockHalf.LOWER));
        set(w, hx + dlx, gy + 2, hz + 4, door.with(Properties.DOUBLE_BLOCK_HALF, DoubleBlockHalf.UPPER));

        // Окна
        for (int lz : new int[]{2, 6}) {
            set(w, hx, gy + 2, hz + lz, glass);
            set(w, hx + 6, gy + 2, hz + lz, glass);
        }
        set(w, hx + 3, gy + 2, hz, glass);
        set(w, hx + 3, gy + 2, hz + 8, glass);

        // Обстановка
        BlockState bedFoot = Blocks.RED_BED.getDefaultState()
                .with(Properties.HORIZONTAL_FACING, Direction.SOUTH)
                .with(Properties.BED_PART, BedPart.FOOT);
        BlockState bedHead = bedFoot.with(Properties.BED_PART, BedPart.HEAD);
        for (int lx : new int[]{1, 5}) {
            set(w, hx + lx, gy + 1, hz + 6, bedFoot);
            set(w, hx + lx, gy + 1, hz + 7, bedHead);
        }
        set(w, hx + 1, gy + 1, hz + 1, Blocks.CRAFTING_TABLE.getDefaultState());
        set(w, hx + 1, gy + 2, hz + 1, Blocks.LANTERN.getDefaultState());
        set(w, hx + 2, gy + 1, hz + 1, Blocks.FURNACE.getDefaultState()
                .with(Properties.HORIZONTAL_FACING, Direction.SOUTH));
        set(w, hx + 5, gy + 1, hz + 1, Blocks.CHEST.getDefaultState()
                .with(Properties.HORIZONTAL_FACING, Direction.SOUTH));
        for (int lx = 2; lx <= 4; lx++) {
            for (int lz = 3; lz <= 5; lz++) {
                set(w, hx + lx, gy + 1, hz + lz, Blocks.RED_CARPET.getDefaultState());
            }
        }
    }

    private static void lamp(ServerWorld w, int x, int gy, int z) {
        set(w, x, gy + 1, z, Blocks.OAK_FENCE.getDefaultState());
        set(w, x, gy + 2, z, Blocks.OAK_FENCE.getDefaultState());
        set(w, x, gy + 3, z, Blocks.LANTERN.getDefaultState());
    }

    private static void sign(ServerWorld w, int x, int y, int z, Direction facing,
                             DyeColor color, boolean glowing, String... lines) {
        BlockPos p = new BlockPos(x, y, z);
        BlockState s = Blocks.OAK_WALL_SIGN.getDefaultState().with(Properties.HORIZONTAL_FACING, facing);
        w.setBlockState(p, s, Block.NOTIFY_ALL);
        if (w.getBlockEntity(p) instanceof SignBlockEntity sign) {
            SignText t = new SignText();
            for (int i = 0; i < Math.min(4, lines.length); i++) {
                t = t.withMessage(i, Text.literal(lines[i]));
            }
            t = t.withColor(color).withGlowing(glowing);
            sign.setText(t, true);
            sign.markDirty();
            w.updateListeners(p, s, s, Block.NOTIFY_ALL);
        }
    }

    private static void set(ServerWorld w, int x, int y, int z, BlockState s) {
        BlockPos p = new BlockPos(x, y, z);
        if (!w.getBlockState(p).equals(s)) {
            w.setBlockState(p, s, Block.NOTIFY_LISTENERS);
        }
    }
}

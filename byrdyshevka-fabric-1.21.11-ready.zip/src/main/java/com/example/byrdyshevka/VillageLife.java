
package com.example.byrdyshevka;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.VindicatorEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.network.packet.s2c.play.SubtitleS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleFadeS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

public final class VillageLife {

    private enum Mode { HOME, TO_POND, SWIM, TO_HOME }

    private static final class State {
        Mode mode = Mode.HOME;
        long until;
        ArrayDeque<Vec3d> route = new ArrayDeque<>();
        Vec3d swimTarget;
    }

    private record Data(double homeX, double homeZ, double inX, double outX, double doorZ,
                        double roadX, int gy, int pcx, int pcz, int rx, int rz) {}

    private static final Map<UUID, State> STATES = new HashMap<>();
    private static final Map<UUID, Data> DATA = new HashMap<>();
    private static final Map<UUID, Long> LAST_SCARE = new HashMap<>();

    private static final Map<RegistryKey<World>, List<? extends VillagerEntity>> BYRDYSHI = new HashMap<>();
    private static final Map<RegistryKey<World>, List<? extends VindicatorEntity>> KLAVAS = new HashMap<>();

    private static final Random RNG = new Random();

    private static final String[] PHRASES = {
            "А ну стой, окаянный!",
            "Ты чего тут ходишь?! Всю грядку мне вытоптал!",
            "Бырдыщей моих не трожь!",
            "Вот я тебя скалкой-то!",
            "Участкового позову!",
            "Ходют тут всякие, а потом тыквы пропадают!"
    };

    private VillageLife() {}

    static String makeTag(double homeX, double homeZ, double inX, double outX, double doorZ,
                          double roadX, int gy, int pcx, int pcz, int rx, int rz) {
        return String.format(Locale.ROOT, "byrdysh;%.2f;%.2f;%.2f;%.2f;%.2f;%.2f;%d;%d;%d;%d;%d",
                homeX, homeZ, inX, outX, doorZ, roadX, gy, pcx, pcz, rx, rz);
    }

    public static void tick(ServerWorld world) {
        long t = world.getTime();
        RegistryKey<World> key = world.getRegistryKey();

        if (t % 20 == 0 || !BYRDYSHI.containsKey(key)) {
            BYRDYSHI.put(key, world.getEntitiesByType(EntityType.VILLAGER, VillageLife::isByrdysh));
            KLAVAS.put(key, world.getEntitiesByType(EntityType.VINDICATOR,
                    k -> k.getCommandTags().contains("klava")));
        }

        for (VillagerEntity v : BYRDYSHI.get(key)) {
            if (!v.isRemoved()) {
                tickByrdysh(world, v, t);
            }
        }

        for (VindicatorEntity k : KLAVAS.get(key)) {
            if (!k.isRemoved()) {
                tickKlava(world, k, t);
            }
        }
    }

    private static boolean isByrdysh(VillagerEntity v) {
        for (String s : v.getCommandTags()) {
            if (s.startsWith("byrdysh;")) {
                return true;
            }
        }
        return false;
    }

    private static Data parse(VillagerEntity v) {
        for (String s : v.getCommandTags()) {
            if (!s.startsWith("byrdysh;")) {
                continue;
            }

            String[] p = s.split(";");

            try {
                return new Data(Double.parseDouble(p[1]), Double.parseDouble(p[2]),
                        Double.parseDouble(p[3]), Double.parseDouble(p[4]),
                        Double.parseDouble(p[5]), Double.parseDouble(p[6]),
                        Integer.parseInt(p[7]), Integer.parseInt(p[8]), Integer.parseInt(p[9]),
                        Integer.parseInt(p[10]), Integer.parseInt(p[11]));
            } catch (RuntimeException e) {
                return null;
            }
        }

        return null;
    }

    private static void tickByrdysh(ServerWorld world, VillagerEntity v, long t) {
        Data d = DATA.get(v.getUuid());

        if (d == null) {
            d = parse(v);
            if (d == null) {
                return;
            }
            DATA.put(v.getUuid(), d);
        }

        State st = STATES.computeIfAbsent(v.getUuid(), k -> {
            State s = new State();
            s.until = t + 60 + RNG.nextInt(600);
            return s;
        });

        v.setVelocity(Vec3d.ZERO);

        switch (st.mode) {
            case HOME -> {
                if (t >= st.until) {
                    st.route = routeOut(d);
                    st.mode = Mode.TO_POND;
                }
            }

            case TO_POND -> {
                if (follow(v, st, 0.10)) {
                    st.mode = Mode.SWIM;
                    st.until = t + 20L * (40 + RNG.nextInt(80));
                    st.swimTarget = randomPondPoint(d);
                }
            }

            case SWIM -> {
                double base = d.gy() - 0.55;

                if (step(v, st.swimTarget, 0.04)) {
                    st.swimTarget = randomPondPoint(d);
                }

                if (Math.abs(v.getY() - base) < 0.4) {
                    double bob = 0.06 * Math.sin((t + v.getId() * 7L) / 8.0);
                    v.setPosition(v.getX(), base + bob, v.getZ());
                }

                if (t % 15 == 0) {
                    world.spawnParticles(ParticleTypes.SPLASH, v.getX(), d.gy() + 1.0, v.getZ(),
                            6, 0.3, 0.05, 0.3, 0.05);
                }

                if (t >= st.until) {
                    st.route = routeBack(d);
                    st.mode = Mode.TO_HOME;
                }
            }

            case TO_HOME -> {
                if (follow(v, st, 0.10)) {
                    st.mode = Mode.HOME;
                    st.until = t + 20L * (30 + RNG.nextInt(90));
                }
            }
        }
    }

    private static ArrayDeque<Vec3d> routeOut(Data d) {
        double y = d.gy() + 1.0;
        ArrayDeque<Vec3d> r = new ArrayDeque<>();

        r.add(new Vec3d(d.inX(), y, d.doorZ()));
        r.add(new Vec3d(d.outX(), y, d.doorZ()));
        r.add(new Vec3d(d.roadX(), y, d.doorZ()));
        r.add(new Vec3d(d.roadX(), y, d.pcz() + 0.5));
        r.add(new Vec3d(d.pcx() + 0.5 + d.rx() * 1.08, y, d.pcz() + 0.5));

        return r;
    }

    private static ArrayDeque<Vec3d> routeBack(Data d) {
        List<Vec3d> list = new ArrayList<>(routeOut(d));
        Collections.reverse(list);
        list.add(new Vec3d(d.homeX(), d.gy() + 1.0, d.homeZ()));
        return new ArrayDeque<>(list);
    }

    private static Vec3d randomPondPoint(Data d) {
        double a = RNG.nextDouble() * Math.PI * 2;
        double r = Math.sqrt(RNG.nextDouble()) * 0.8;

        return new Vec3d(d.pcx() + 0.5 + Math.cos(a) * d.rx() * r,
                d.gy() - 0.55,
                d.pcz() + 0.5 + Math.sin(a) * d.rz() * r);
    }

    private static boolean follow(VillagerEntity v, State st, double speed) {
        Vec3d next = st.route.peekFirst();

        if (next == null) {
            return true;
        }

        if (step(v, next, speed)) {
            st.route.pollFirst();
        }

        return st.route.isEmpty();
    }

    private static boolean step(VillagerEntity v, Vec3d target, double speed) {
        double dx = target.x - v.getX();
        double dz = target.z - v.getZ();
        double dist = Math.sqrt(dx * dx + dz * dz);

        if (dist > 0.001) {
            float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
            v.setYaw(yaw);
            v.setHeadYaw(yaw);
            v.setBodyYaw(yaw);
            v.setPitch(0f);
        }

        if (dist <= speed) {
            v.setPosition(target.x, target.y, target.z);
            return true;
        }

        double k = speed / dist;

        v.setPosition(v.getX() + dx * k,
                v.getY() + (target.y - v.getY()) * k,
                v.getZ() + dz * k);

        return false;
    }

    private static void tickKlava(ServerWorld world, VindicatorEntity k, long t) {
        if (t % 10 != 0) {
            return;
        }

        ServerPlayerEntity nearest = null;
        double best = 48.0 * 48.0;

        for (ServerPlayerEntity p : world.getPlayers()) {
            if (!p.isAlive() || p.isSpectator()) {
                continue;
            }

            double dist = p.squaredDistanceTo(k);

            if (dist < best) {
                best = dist;
                nearest = p;
            }
        }

        if (nearest == null) {
            return;
        }

        k.setTarget(nearest);

        if (best < 49.0 && k.canSee(nearest)) {
            Long last = LAST_SCARE.get(nearest.getUuid());

            if (last == null || t - last > 1200) {
                LAST_SCARE.put(nearest.getUuid(), t);
                scare(world, nearest);
            }
        }

        if (best < 24.0 * 24.0 && RNG.nextInt(60) == 0) {
            nearest.sendMessage(Text.literal("<Баба Клава> " +
                    PHRASES[RNG.nextInt(PHRASES.length)]), false);
        }
    }

    private static void scare(ServerWorld world, ServerPlayerEntity p) {
        p.networkHandler.sendPacket(new TitleFadeS2CPacket(0, 40, 15));

        p.networkHandler.sendPacket(new SubtitleS2CPacket(
                Text.literal("ТЫ ЧЕГО ТУТ ВЫСМАТРИВАЕШЬ?!")
                        .formatted(Formatting.YELLOW)));

        p.networkHandler.sendPacket(new TitleS2CPacket(
                Text.literal("БАБА КЛАВА!!!")
                        .formatted(Formatting.DARK_RED, Formatting.BOLD)));

        p.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 25, 0));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 120, 0));

        world.playSound(null, p.getX(), p.getY(), p.getZ(),
                SoundEvents.ENTITY_GHAST_SCREAM, SoundCategory.HOSTILE, 4.0f, 0.6f);

        world.playSound(null, p.getX(), p.getY(), p.getZ(),
                SoundEvents.ENTITY_ENDER_DRAGON_GROWL, SoundCategory.HOSTILE, 3.0f, 0.8f);
    }
}

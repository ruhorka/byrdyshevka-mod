
package com.example.byrdyshevka;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;

public class Byrdyshevka implements ModInitializer {

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(CommandManager.literal("byrdyshevka")
                        .requires(src -> src.getPlayer() != null)
                        .executes(ctx -> {
                            ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                            ServerWorld world = player.getEntityWorld();
                            VillageBuilder.build(world, player.getBlockPos().down());
                            ctx.getSource().sendFeedback(
                                    () -> Text.literal("Село Бырдыщевка построено! Осторожно, баба Клава рядом."),
                                    true);
                            return 1;
                        })));

        ServerTickEvents.END_WORLD_TICK.register(VillageLife::tick);
    }
}
